# Pakistan AI

Native Kotlin Android chat app (Jetpack Compose, Material 3, MVVM) that uses your own Gemini API key.

- Package: `com.pakistan.ai`
- Min SDK 24, target SDK 34

## Build on GitHub Actions
Push this project to a GitHub repo. The workflow in `.github/workflows/build-apk.yml` builds
`app-debug.apk` and uploads it as the `Pakistan-AI-APK` artifact.

## Build locally
Install JDK 17, the Android SDK and Gradle 8.7, then run `gradle assembleDebug`.

## Setup in the app
Open Settings, paste your Gemini API key, tap FETCH MODELS, pick a model, then TEST CONNECTION.
