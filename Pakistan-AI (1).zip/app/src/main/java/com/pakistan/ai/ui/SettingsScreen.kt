package com.pakistan.ai.ui

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.pakistan.ai.data.AppPrefs
import com.pakistan.ai.data.ChatTurn
import com.pakistan.ai.data.GeminiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val languages = listOf("en-US", "ur-PK", "en-GB", "hi-IN")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(prefs: AppPrefs, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val client = remember { GeminiClient() }
    val snackbar = remember { SnackbarHostState() }

    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var voice by remember { mutableStateOf(prefs.voiceName) }
    var language by remember { mutableStateOf(prefs.language) }
    var memory by remember { mutableStateOf(prefs.systemPrompt) }

    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var showModels by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var voiceMenu by remember { mutableStateOf(false) }
    var lastOk by remember { mutableStateOf(true) }

    var ttsReady by remember { mutableStateOf(false) }
    var voices by remember { mutableStateOf<List<String>>(emptyList()) }

    val tts = remember { TextToSpeech(context) { ttsReady = it == TextToSpeech.SUCCESS } }
    DisposableEffect(Unit) {
        onDispose { tts.shutdown() }
    }

    LaunchedEffect(ttsReady) {
        if (ttsReady) voices = tts.voices?.map { it.name }?.sorted() ?: emptyList()
    }
    LaunchedEffect(ttsReady, language) {
        if (ttsReady) tts.language = Locale.forLanguageTag(language)
    }
    LaunchedEffect(ttsReady, voice) {
        if (ttsReady && voice.isNotBlank()) {
            tts.voices?.firstOrNull { it.name == voice }?.let { tts.voice = it }
        }
    }

    fun notify(ok: Boolean, message: String) {
        lastOk = ok
        scope.launch { snackbar.showSnackbar(message) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = {
            SnackbarHost(snackbar) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = if (lastOk) Color(0xFF2E7D32) else Color(0xFFC62828),
                    contentColor = Color.White
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Sections A, B, C: API key, fetch models, test connection
            Text("Gemini API Key", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it; prefs.apiKey = it },
                label = { Text("API key") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { client.listModels(apiKey) }
                        result
                            .onSuccess {
                                models = it
                                showModels = true
                                if (it.isEmpty()) notify(false, "No text models found for this key")
                            }
                            .onFailure { notify(false, "Fetch failed: ${it.message}") }
                    }
                }) { Text("FETCH MODELS") }

                Button(onClick = {
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            client.generate(apiKey, model, "", listOf(ChatTurn("user", "hello")))
                        }
                        result
                            .onSuccess { notify(true, "Successfully Connected") }
                            .onFailure { notify(false, "Connection Failed: ${it.message}") }
                    }
                }) { Text("TEST CONNECTION") }
            }
            Text(
                "Selected model: ${model.removePrefix("models/")}",
                style = MaterialTheme.typography.bodySmall
            )

            HorizontalDivider()

            // Section D: voice selector
            Text("Voice", style = MaterialTheme.typography.titleMedium)
            Box {
                OutlinedButton(onClick = { voiceMenu = true }) {
                    Text(if (voice.isBlank()) "Select voice" else voice)
                }
                DropdownMenu(expanded = voiceMenu, onDismissRequest = { voiceMenu = false }) {
                    if (voices.isEmpty()) {
                        DropdownMenuItem(text = { Text("No voices found") }, onClick = { voiceMenu = false })
                    }
                    voices.forEach { name ->
                        DropdownMenuItem(
                            text = { Text(name) },
                            onClick = {
                                voice = name
                                prefs.voiceName = name
                                voiceMenu = false
                            }
                        )
                    }
                }
            }
            Button(onClick = {
                tts.speak("This is the selected voice.", TextToSpeech.QUEUE_FLUSH, null, "test")
            }) { Text("TEST VOICE") }

            HorizontalDivider()

            // Section E: language
            Text("Language (speech and voice)", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                languages.forEach { code ->
                    FilterChip(
                        selected = language == code,
                        onClick = {
                            language = code
                            prefs.language = code
                        },
                        label = { Text(code) }
                    )
                }
            }

            HorizontalDivider()

            // Section F: memory / system prompt
            OutlinedTextField(
                value = memory,
                onValueChange = { memory = it; prefs.systemPrompt = it },
                label = { Text("Custom System Prompt / Your Memory") },
                placeholder = { Text("You are Pakistan AI, my personal assistant...") },
                minLines = 5,
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            // Section G: about
            Card(onClick = { showAbout = true }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("About / Licenses", style = MaterialTheme.typography.titleMedium)
                    Text("Tap to read", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    if (showModels) {
        AlertDialog(
            onDismissRequest = { showModels = false },
            title = { Text("Choose a model") },
            text = {
                LazyColumn(Modifier.height(300.dp)) {
                    items(models) { name ->
                        Text(
                            text = name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    model = name
                                    prefs.model = name
                                    showModels = false
                                }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showModels = false }) { Text("Close") }
            }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("About") },
            text = {
                Text("This app uses your own Gemini API key. No data is collected. All chat is direct to Google.")
            },
            confirmButton = {
                TextButton(onClick = { showAbout = false }) { Text("OK") }
            }
        )
    }
}
