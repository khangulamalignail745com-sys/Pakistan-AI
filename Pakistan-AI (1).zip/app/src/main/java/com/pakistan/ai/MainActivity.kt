package com.pakistan.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.pakistan.ai.ui.AppNavHost
import com.pakistan.ai.ui.theme.PakistanAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PakistanAITheme {
                AppNavHost()
            }
        }
    }
}
