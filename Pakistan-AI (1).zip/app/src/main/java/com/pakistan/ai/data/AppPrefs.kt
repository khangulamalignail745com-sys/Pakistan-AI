package com.pakistan.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores user settings. The API key is kept in encrypted storage;
 * everything else is ordinary preferences.
 */
class AppPrefs(context: Context) {

    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val plain: SharedPreferences = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(value) = secure.edit().putString("api_key", value).apply()

    var model: String
        get() = plain.getString("model", "models/gemini-1.5-flash") ?: "models/gemini-1.5-flash"
        set(value) = plain.edit().putString("model", value).apply()

    var voiceName: String
        get() = plain.getString("voice", "") ?: ""
        set(value) = plain.edit().putString("voice", value).apply()

    var language: String
        get() = plain.getString("language", "en-US") ?: "en-US"
        set(value) = plain.edit().putString("language", value).apply()

    var systemPrompt: String
        get() = plain.getString("system_prompt", "You are Pakistan AI, a helpful assistant.") ?: ""
        set(value) = plain.edit().putString("system_prompt", value).apply()
}
