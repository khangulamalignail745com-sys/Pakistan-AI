package com.pakistan.ai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pakistan.ai.data.AppPrefs
import com.pakistan.ai.data.ChatTurn
import com.pakistan.ai.data.GeminiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Holds the text chat state and talks to Gemini. */
class ChatViewModel(private val prefs: AppPrefs) : ViewModel() {

    private val client = GeminiClient()

    private val _messages = MutableStateFlow<List<ChatTurn>>(emptyList())
    val messages: StateFlow<List<ChatTurn>> = _messages.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun send(text: String, imageBase64: String? = null, imageMime: String? = null) {
        _messages.value = _messages.value + ChatTurn("user", text, imageBase64, imageMime)
        val history = _messages.value

        viewModelScope.launch {
            _busy.value = true
            val result = withContext(Dispatchers.IO) {
                client.generate(prefs.apiKey, prefs.model, prefs.systemPrompt, history)
            }
            result
                .onSuccess { reply -> _messages.value = _messages.value + ChatTurn("model", reply) }
                .onFailure { _error.value = it.message ?: "Unknown error" }
            _busy.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }
}
