package com.pakistan.ai.ui

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.pakistan.ai.data.AppPrefs
import com.pakistan.ai.data.ChatTurn
import com.pakistan.ai.data.GeminiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Voice-to-voice conversation: speech in, Gemini reply, spoken reply out.
 * Optional camera: "Capture & Ask" sends a photo with a description request.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(prefs: AppPrefs, onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val client = remember { GeminiClient() }
    val turns = remember { mutableStateListOf<ChatTurn>() }

    var status by remember { mutableStateOf("Tap the mic and start talking") }
    var listening by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }
    var cameraOn by remember { mutableStateOf(false) }
    var useFront by remember { mutableStateOf(false) }

    val tts = remember { TextToSpeech(context) { ttsReady = it == TextToSpeech.SUCCESS } }
    val recognizer = remember { SpeechRecognizer.createSpeechRecognizer(context) }
    val previewView = remember { PreviewView(context) }
    val imageCapture = remember { ImageCapture.Builder().build() }
    val providerHolder = remember { mutableStateOf<ProcessCameraProvider?>(null) }

    LaunchedEffect(ttsReady) {
        if (ttsReady) {
            tts.language = Locale.forLanguageTag(prefs.language)
            val name = prefs.voiceName
            if (name.isNotBlank()) {
                tts.voices?.firstOrNull { it.name == name }?.let { tts.voice = it }
            }
        }
    }

    fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    fun ask(userText: String, imageB64: String? = null, mime: String? = null) {
        turns.add(ChatTurn("user", userText, imageB64, mime))
        val history = turns.toList()
        busy = true
        status = "Thinking..."
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                client.generate(prefs.apiKey, prefs.model, prefs.systemPrompt, history)
            }
            busy = false
            result
                .onSuccess { reply ->
                    turns.add(ChatTurn("model", reply))
                    status = "Speaking..."
                    speak(reply)
                }
                .onFailure { status = "Error: ${it.message}" }
        }
    }

    DisposableEffect(Unit) {
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(error: Int) {
                listening = false
                status = "Could not hear you (code $error). Tap the mic to retry."
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) ask(text) else status = "Nothing heard. Tap the mic to retry."
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        onDispose {
            recognizer.destroy()
            tts.shutdown()
            providerHolder.value?.unbindAll()
        }
    }

    DisposableEffect(cameraOn, useFront) {
        if (cameraOn) {
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                val provider = future.get()
                providerHolder.value = provider
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
            }, ContextCompat.getMainExecutor(context))
        }
        onDispose {
            providerHolder.value?.unbindAll()
        }
    }

    fun captureAndAsk() {
        imageCapture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining()).also { buffer.get(it) }
                    image.close()
                    ask(
                        "Describe what you see in front of me.",
                        Base64.encodeToString(bytes, Base64.NO_WRAP),
                        "image/jpeg"
                    )
                }

                override fun onError(exception: ImageCaptureException) {
                    status = "Capture failed: ${exception.message}"
                }
            }
        )
    }

    fun toggleListening() {
        if (listening) {
            recognizer.stopListening()
            listening = false
            return
        }
        if (busy) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.language)
        listening = true
        recognizer.startListening(intent)
    }

    val pulse by rememberInfiniteTransition(label = "mic-pulse").animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(animation = tween(700), repeatMode = RepeatMode.Reverse),
        label = "mic-pulse-scale"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Voice Chat") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Camera")
                Switch(checked = cameraOn, onCheckedChange = { cameraOn = it })
                OutlinedButton(onClick = { useFront = !useFront }) {
                    Text(if (useFront) "Switch camera: Front" else "Switch camera: Back")
                }
            }

            if (cameraOn) {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
                Button(onClick = { captureAndAsk() }, enabled = !busy) {
                    Text("Capture & Ask")
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(turns) { turn ->
                    Text(if (turn.role == "user") "You: ${turn.text}" else "AI: ${turn.text}")
                }
            }

            Text(status, style = MaterialTheme.typography.bodyMedium)

            Box(
                modifier = Modifier
                    .size(110.dp)
                    .scale(if (listening) pulse else 1f)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable(enabled = !busy) { toggleListening() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Talk", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}
