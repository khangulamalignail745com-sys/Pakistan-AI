package com.pakistan.ai.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** One message in the conversation. Optionally carries an inline image or file. */
data class ChatTurn(
    val role: String,            // "user" or "model"
    val text: String,
    val imageBase64: String? = null,
    val imageMime: String? = null
)

/**
 * Minimal Gemini REST client. The API key is sent in a header,
 * not in the URL, so it does not appear in logs.
 */
class GeminiClient {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val baseUrl = "https://generativelanguage.googleapis.com/v1beta/"

    /** Returns model names (e.g. "models/gemini-1.5-flash") that support generateContent. */
    fun listModels(apiKey: String): Result<List<String>> = runCatching {
        val request = Request.Builder()
            .url("${baseUrl}models?pageSize=100")
            .header("x-goog-api-key", apiKey)
            .get()
            .build()

        http.newCall(request).execute().use { response ->
            val body = response.body.string()
            if (!response.isSuccessful) error("HTTP ${response.code}: ${errorMessage(body)}")
            val models = JSONObject(body).getJSONArray("models")
            buildList<String> {
                for (i in 0 until models.length()) {
                    val model = models.getJSONObject(i)
                    if (supportsGenerate(model.optJSONArray("supportedGenerationMethods"))) {
                        add(model.getString("name"))
                    }
                }
            }
        }
    }

    /** Sends the conversation to a model and returns the reply text. */
    fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        turns: List<ChatTurn>
    ): Result<String> = runCatching {
        val contents = JSONArray()
        for (turn in turns) {
            val parts = JSONArray()
            if (turn.text.isNotBlank()) {
                parts.put(JSONObject().put("text", turn.text))
            }
            if (turn.imageBase64 != null && turn.imageMime != null) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject()
                            .put("mime_type", turn.imageMime)
                            .put("data", turn.imageBase64)
                    )
                )
            }
            contents.put(
                JSONObject()
                    .put("role", if (turn.role == "user") "user" else "model")
                    .put("parts", parts)
            )
        }

        val payload = JSONObject().put("contents", contents)
        if (systemPrompt.isNotBlank()) {
            payload.put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
        }

        val modelPath = if (model.startsWith("models/")) model else "models/$model"
        val request = Request.Builder()
            .url("$baseUrl$modelPath:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(payload.toString().toRequestBody(jsonType))
            .build()

        http.newCall(request).execute().use { response ->
            val body = response.body.string()
            if (!response.isSuccessful) error("HTTP ${response.code}: ${errorMessage(body)}")
            val parts = JSONObject(body)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
            (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        }
    }

    private fun supportsGenerate(methods: JSONArray?): Boolean {
        if (methods == null) return false
        return (0 until methods.length()).any { methods.getString(it) == "generateContent" }
    }

    private fun errorMessage(body: String): String =
        runCatching { JSONObject(body).getJSONObject("error").getString("message") }
            .getOrDefault(body.take(200))
}
