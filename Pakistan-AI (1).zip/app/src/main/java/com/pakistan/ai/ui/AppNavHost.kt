package com.pakistan.ai.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pakistan.ai.data.AppPrefs

@Composable
fun AppNavHost() {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen(onFinished = {
                nav.navigate("chat") { popUpTo("splash") { inclusive = true } }
            })
        }
        composable("chat") {
            ChatScreen(
                prefs = prefs,
                onOpenSettings = { nav.navigate("settings") },
                onOpenVoice = { nav.navigate("voice") }
            )
        }
        composable("settings") {
            SettingsScreen(prefs = prefs, onBack = { nav.popBackStack() })
        }
        composable("voice") {
            VoiceScreen(prefs = prefs, onBack = { nav.popBackStack() })
        }
    }
}
