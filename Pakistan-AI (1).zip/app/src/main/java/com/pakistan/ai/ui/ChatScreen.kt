package com.pakistan.ai.ui

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistan.ai.data.AppPrefs
import com.pakistan.ai.data.ChatTurn
import com.pakistan.ai.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(prefs: AppPrefs, onOpenSettings: () -> Unit, onOpenVoice: () -> Unit) {
    val vm: ChatViewModel = viewModel { ChatViewModel(prefs) }
    val messages by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val error by vm.error.collectAsState()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val snackbar = remember { SnackbarHostState() }

    var input by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Pair<String, String>?>(null) } // base64 to mime
    var pendingName by remember { mutableStateOf("") }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }
    LaunchedEffect(error) {
        error?.let {
            snackbar.showSnackbar(it)
            vm.clearError()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val bytes = runCatching {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            }.getOrNull()
            when {
                bytes == null -> scope.launch { snackbar.showSnackbar("Could not read that file") }
                bytes.size > 15 * 1024 * 1024 -> scope.launch { snackbar.showSnackbar("File too large (max 15 MB)") }
                else -> {
                    pending = Base64.encodeToString(bytes, Base64.NO_WRAP) to mime
                    pendingName = uri.lastPathSegment ?: "file"
                }
            }
        }
    }

    fun send() {
        val attachment = pending
        if (input.isBlank() && attachment == null) return
        vm.send(input.trim(), attachment?.first, attachment?.second)
        input = ""
        pending = null
        pendingName = ""
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pakistan AI") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                if (pending != null) {
                    AssistChip(
                        onClick = { pending = null; pendingName = "" },
                        label = { Text("Attached: $pendingName (tap to remove)") }
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { picker.launch("*/*") }, enabled = !busy) {
                        Icon(Icons.Default.AttachFile, contentDescription = "Attach file")
                    }
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text("Ask anything...") },
                        modifier = Modifier.weight(1f),
                        maxLines = 4
                    )
                    IconButton(onClick = { send() }, enabled = !busy) {
                        Icon(Icons.Default.Send, contentDescription = "Send")
                    }
                    FilledIconButton(onClick = onOpenVoice) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice conversation")
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { turn -> MessageBubble(turn) }
            if (busy) {
                item { CircularProgressIndicator(Modifier.padding(8.dp)) }
            }
        }
    }
}

@Composable
private fun MessageBubble(turn: ChatTurn) {
    val isUser = turn.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(10.dp)) {
                val image = turn.imageBase64
                if (image != null) {
                    if (turn.imageMime?.startsWith("image/") == true) {
                        val bitmap = remember(image) {
                            runCatching {
                                val bytes = Base64.decode(image, Base64.DEFAULT)
                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                            }.getOrNull()
                        }
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap,
                                contentDescription = "Attached image",
                                modifier = Modifier.size(180.dp).clip(RoundedCornerShape(10.dp))
                            )
                            Spacer(Modifier.height(6.dp))
                        }
                    } else {
                        Text("[Attached: ${turn.imageMime}]")
                        Spacer(Modifier.height(6.dp))
                    }
                }
                if (turn.text.isNotBlank()) Text(turn.text)
            }
        }
    }
}
