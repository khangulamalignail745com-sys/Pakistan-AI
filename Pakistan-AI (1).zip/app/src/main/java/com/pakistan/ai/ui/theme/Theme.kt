package com.pakistan.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF01411C)
private val Gold = Color(0xFFD4AF37)

private val LightScheme = lightColorScheme(
    primary = Green,
    onPrimary = Color.White,
    secondary = Gold
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8BD8A6),
    onPrimary = Color(0xFF00391A),
    secondary = Gold
)

@Composable
fun PakistanAITheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme,
        content = content
    )
}
